package sample;

public class Rezept {
    public String name;

    public Rezept(String s) {
        this.name=s;
    }
}
